def bool_to_word bool
  if bool == true
  "Yes"
  else "No"
  end
end