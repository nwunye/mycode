def doubleInteger(i)
i*2
end