def greet(name)
  newname = name.downcase.capitalize
  puts "Hello " << newname << "!"
end

greet("ikem")