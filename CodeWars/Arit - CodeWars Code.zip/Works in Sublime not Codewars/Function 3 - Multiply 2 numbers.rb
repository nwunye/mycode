def multiply(a,b)
  print a*b
end

multiply(2,5)