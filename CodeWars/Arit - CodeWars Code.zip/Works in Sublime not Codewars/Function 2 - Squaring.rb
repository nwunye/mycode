def square(number)
  puts number*number
end

square(5)