a = "code"
b = "wa.rs"
varname = a + b
puts varname