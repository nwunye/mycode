items = Array.new
items.push {:a >> "b", :c >> "d"}

# URL: http://www.codewars.com/kata/527b3cd0492b6b15250060af/train/ruby