def nthterm()
# Write here !
end

# URL: http://www.codewars.com/kata/540f8a19a7d43d24ac001018/train/ruby